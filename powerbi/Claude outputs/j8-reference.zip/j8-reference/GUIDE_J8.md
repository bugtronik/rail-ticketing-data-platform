# J8 — Dashboard Power BI : guide pas à pas

5 commits. Les 3 premiers (compte `bi_reader`, droits dbt, documentation
du modèle) ont été rejoués sur une copie de ton dépôt et testés sur un
entrepôt neuf : `bi_reader` lit les 8 tables des marts, et il est refusé
sur `raw`, `staging`, `snapshots` et sur tout `CREATE`.

**Ce que je n'ai pas pu tester : Power BI lui-même** (Windows uniquement).
D'où la requête `dashboard_checks.sql` : elle calcule en SQL la valeur
attendue de chaque mesure. Ton rapport est juste quand chaque carte affiche
le même chiffre qu'elle. C'est **ta** partie du projet, la plus visible :
prends le temps de la soigner.

## Étape 0 — Préparer

**Prérequis : les 2 commits de `GUIDE_ENV.md`** (`make env` et le README
corrigé). Cette référence part de là : son `Makefile` et son `README.md`
les contiennent déjà.

```bash
cd ~/projects/rail-ticketing-data-platform
git pull && git status                          # propre, sur "docs: installation requirements..."
unzip -o /mnt/c/Users/<toi>/Downloads/j8-reference.zip -d ~ && REF=~/j8-reference
cat >> .env <<EOF
# Power BI account: reads the marts schema only.
BI_READER_PASSWORD=$(python3 -c "import secrets; print(secrets.token_urlsafe(16))")
EOF
grep BI_READER_PASSWORD .env                    # note-le : Power BI te le demandera
```

> **Pourquoi pas `make env` ?** Il refuse d'écraser un `.env` existant, et
> c'est voulu : le tien contient les mots de passe de bases déjà créées.
> Une variable **nouvelle** s'ajoute donc à la main, une seule fois. Une
> installation neuve, elle, l'aura directement : le commit 1 ajoute
> `BI_READER_PASSWORD=change_me_bi` à `.env.example`, et `make env`
> remplace tout `change_me…` par une valeur aléatoire.

---

## Commit 1 — Le compte `bi_reader`

```bash
cp $REF/warehouse/init/04_bi_reader.sh warehouse/init/
mkdir -p warehouse/migrations && cp $REF/warehouse/migrations/0002_j8_bi_reader.sh warehouse/migrations/
cp $REF/docker-compose.yml $REF/.env.example $REF/Makefile .
ls -l warehouse/init/04_bi_reader.sh            # PAS de x : il est sourcé, comme 01 et 03
docker compose up -d --wait warehouse           # recrée le conteneur avec BI_READER_PASSWORD (le volume reste)
make migrate-warehouse                          # 0001 (déjà fait, sans effet) puis 0002 : CREATE ROLE
make migrate-warehouse                          # 2e fois : plus de CREATE ROLE, rien ne casse
git add warehouse docker-compose.yml .env.example Makefile
git commit -m "feat(warehouse): add the read-only bi_reader account for Power BI"
```

**À lire :** `04_bi_reader.sh`, en particulier le `\gexec`. Le `SELECT` ne
renvoie la commande `CREATE ROLE` que si le rôle n'existe pas encore, et
`\gexec` l'exécute. C'est ce qui rend le script rejouable, alors que
PostgreSQL n'a pas de `CREATE ROLE IF NOT EXISTS`. Et la migration
`0002` se contente d'exécuter **le même** script : il n'y a qu'une
définition du compte.

---

## Commit 2 — dbt donne les droits de lecture

```bash
cp $REF/transform/dbt_project.yml transform/
git diff                                        # 3 lignes : +grants
make transform
```

Vérifie le moindre privilège toi-même :

```bash
PGPW=$(grep BI_READER_PASSWORD .env | cut -d= -f2)
docker compose exec -T -e PGPASSWORD="$PGPW" warehouse psql -h 127.0.0.1 -U bi_reader -d warehouse -c "SELECT COUNT(*) FROM marts.fct_tickets"   # OK
docker compose exec -T -e PGPASSWORD="$PGPW" warehouse psql -h 127.0.0.1 -U bi_reader -d warehouse -c "SELECT COUNT(*) FROM raw.customers"     # permission denied
```

`-h 127.0.0.1` force une connexion réseau : dans le conteneur, une
connexion locale sans `-h` serait acceptée sans mot de passe (`trust`), et
le test ne prouverait rien.

> **Pourquoi les droits sont-ils dans dbt et pas dans le script SQL ?** dbt
> **recrée** les tables des marts à chaque run (une nouvelle table, puis un
> renommage). Un `GRANT SELECT` donné une seule fois disparaîtrait avec
> l'ancienne table au run suivant. Avec `grants`, dbt redonne le droit à
> chaque reconstruction.

Comme pour J7, l'image Airflow doit embarquer ce changement, sinon le
prochain run horaire reconstruirait les tables **sans** les droits :

```bash
make up && make run
git add transform && git commit -m "feat(transform): grant read access on the marts to bi_reader"
```

---

## Commit 3 — Le modèle documenté et ses chiffres de contrôle

```bash
mkdir -p powerbi
cp $REF/powerbi/README.md powerbi/
cp $REF/transform/analyses/dashboard_checks.sql transform/analyses/
cp $REF/.gitignore .
uv run --env-file .env dbt compile --select dashboard_checks --project-dir transform --profiles-dir transform
docker compose exec -T warehouse psql -U warehouse_admin -d warehouse \
  < transform/target/compiled/rail_ticketing/analyses/dashboard_checks.sql
git add powerbi transform .gitignore
git commit -m "docs(powerbi): document the model and measures, with SQL checks"
```

**Garde la sortie de `dashboard_checks` sous les yeux** : ce sont tes
valeurs cibles. **Lis `powerbi/README.md` en entier** avant d'ouvrir Power
BI : c'est le plan du modèle que tu vas construire.

Les données bougent toutes les heures (générateur `live`). Pour comparer
tes cartes aux chiffres de contrôle, relance la requête **juste après**
avoir actualisé Power BI.

---

## Construire le rapport dans Power BI Desktop

### A. Paramètres et connexion

1. **Accueil → Transformer les données → Gérer les paramètres → Nouveau** :
   - `WarehouseServer`, type Texte, valeur `localhost:5433` (ton
     `WAREHOUSE_PORT`) ;
   - `WarehouseDatabase`, type Texte, valeur `warehouse`.
2. **Nouvelle source → PostgreSQL**. Serveur et base : choisis
   **Paramètre** puis `WarehouseServer` et `WarehouseDatabase`. Mode
   **Importer**.
3. Identifiants : onglet **Base de données**, `bi_reader` et son mot de
   passe. Power BI proposera ensuite de se connecter **sans chiffrement** :
   accepte, PostgreSQL tourne en local sans certificat.
4. Coche les 8 tables `marts.*` (tu ne vois que celles-là : c'est
   `bi_reader` qui travaille). Renomme-les sans le préfixe `marts` pour
   qu'elles aient les mêmes noms que dans la doc : `fct_tickets`,
   `dim_date`…

### B. Le modèle (vue Modèle)

1. **Supprime toutes les relations détectées automatiquement**, puis crée
   celles du schéma de `powerbi/README.md`. Toutes en **plusieurs à un**,
   filtrage **unique** (de la dimension vers le fait).
2. `fct_tickets[departure_date]` → `dim_date[date_day]` et
   `fct_tickets[destination_station_id]` → `dim_station[station_id]` :
   décoche **Rendre cette relation active**.
3. `dim_customer` se relie par **`customer_sk`**, pas par `customer_id`.
4. Ne relie pas `fct_trip_occupancy` à `dim_trip`.
5. `dim_date` : **Marquer comme table de dates** (colonne `date_day`).
   `month_name` → **Trier par colonne** `month_number`, `day_name` →
   `day_of_week`.
6. Masque les colonnes de clés dans les tables de faits (`*_id`,
   `customer_sk`) : on filtre par les dimensions, jamais par les clés.

### C. Les mesures

**Accueil → Entrer des données**, table vide nommée `Mesures`. Crée-y les
13 mesures de `powerbi/README.md` (Nouvelle mesure, puis copier-coller).
Formats : montants en nombre entier avec séparateur de milliers, taux en
**Pourcentage** avec 1 décimale.

**Contrôle :** sur une page vide, mets une carte par mesure, sans aucun
filtre. Les 9 mesures listées par `dashboard_checks` doivent afficher
**exactement** ses valeurs (aux arrondis d'affichage près). Sans filtre,
`CA par date de voyage` doit aussi être égal au `CA brut` : ce sont les
mêmes billets, seulement rangés par une autre date. Si une
carte ne correspond pas, c'est la mesure ou une relation qui est fausse,
pas les données.

### D. Les 3 pages

Mets un filtre de page sur `dim_date[date_day]` : **Date relative → dans
les 24 derniers mois calendaires**. Il exclut le mois en cours, qui est
incomplet (c'est la remarque de J4 sur les mois partiels).

| Page | Visuels suggérés |
|---|---|
| **Ventes** | cartes CA brut, CA net, Billets vendus, Prix moyen ; courbe CA brut par `dim_date[month_key]` avec `dim_line[line_name]` en légende ; barres Taux d'annulation par `fct_tickets[fare_type]` ; segments Année et Canal |
| **Remplissage** | carte Taux de remplissage ; colonnes groupées Taux de remplissage par `month_key` et ligne ; matrice ligne × mois avec mise en forme conditionnelle |
| **Canaux et heures** | barres CA brut par `dim_channel[channel_name]` ; courbe Part du CA en ligne par `month_key` ; colonnes Billets vendus par `fct_tickets[order_hour]` ; colonnes Billets vendus par `dim_trip[departure_hour]` |

Le design t'appartient. Seule règle : un taux ne s'affiche **jamais** avec
un « Moyenne » de Power BI, mais uniquement avec sa mesure.

### E. Enregistrer en PBIP

**Fichier → Enregistrer sous → Projet Power BI (*.pbip)**, nom
`rail_ticketing`.

- **Essaie d'abord directement dans le dépôt** :
  `\\wsl.localhost\Ubuntu\home\bugtronik\projects\rail-ticketing-data-platform\powerbi\`.
- Si Desktop refuse ou se plaint d'un chemin réseau, enregistre sous
  Windows (`C:\Users\<toi>\Documents\rail_ticketing\`), puis copie dans le
  dépôt depuis WSL :
  ```bash
  cp -r /mnt/c/Users/<toi>/Documents/rail_ticketing/* powerbi/
  ```

---

## Commit 4 — Le rapport

Ton projet Power BI est dans OneDrive, hors du dépôt : on le copie dans
`powerbi/`, **sans** le cache de données (`cache.abf`, plusieurs Mo, et il
contient les données elles-mêmes) ni les réglages locaux. Ferme d'abord
Power BI Desktop, pour copier des fichiers qui ne bougent plus.

```bash
SRC="/mnt/c/Users/aly.mboumba/OneDrive - Eramet SA/Data Engineer & DataOps/Business Intelligence/rail-ticketing-project"
rsync -a --exclude cache.abf --exclude localSettings.json --exclude .gitignore "$SRC"/ powerbi/
cp $REF/powerbi/README.md powerbi/              # la doc décrit maintenant les 3 pages, les KPI 30 j et le thème
git status powerbi/                             # rail-ticketing.pbip, .Report/, .SemanticModel/, README.md
git status --ignored powerbi/ | grep -E "cache.abf|localSettings"   # rien : ils n'ont pas été copiés
grep -ri "password\|bi_reader" powerbi/*.pbip powerbi/rail-ticketing.* || echo "aucun identifiant dans les fichiers"
git add powerbi
git commit -m "feat(powerbi): add the sales, operations and channels report"
```

Si `rsync` manque : `sudo apt install rsync`. `rsync -a` copie aussi les dossiers cachés (`.pbi/`, `.platform`), que
`cp *` oublierait. Les `--exclude` font le même travail que le
`.gitignore`, mais **avant** la copie : le cache ne quitte même pas OneDrive.

Ouvre `powerbi/rail-ticketing.SemanticModel/definition/tables/Mesures.tmdl` :
chaque mesure y est du texte, avec son dossier d'affichage et son format.
Change le format d'une mesure dans Desktop, enregistre, recopie avec la même
commande `rsync`, puis lance `git diff` : tu verras exactement la ligne
modifiée. C'est tout l'intérêt du PBIP.

## Commit 5 — Captures et documentation

Fais une capture de chaque page (plein écran, sans tes favoris ni ta barre
des tâches) et enregistre-les sous **exactement** ces noms :

```
docs/images/dashboard-sales.png
docs/images/dashboard-load-factor.png
docs/images/dashboard-channels.png
```

```bash
cp $REF/README.md . && cp $REF/docs/adr/0009-power-bi-layer.md docs/adr/
git add README.md docs
git commit -m "docs: add the dashboard section and ADR 0009 on the Power BI layer"
git show --stat HEAD                            # README, ADR, 3 images
make lint && git push
```

Ouvre ton README sur GitHub pour vérifier que les 3 images s'affichent.
Une fois la CI verte :

```bash
git tag -a v0.9.0 main -m "J8 - Power BI dashboard" && git push origin v0.9.0
```

## Questions d'entretien à savoir traiter

1. Pourquoi un compte dédié, et pourquoi ses droits sont-ils donnés par dbt ?
2. Import ou DirectQuery : qu'est-ce qui te ferait changer ?
3. Pourquoi le taux de remplissage est-il une mesure DAX et pas une colonne ?
   Que ferait Power BI avec une colonne `load_factor` par trajet ?
4. Deux relations entre `fct_tickets` et `dim_date` : comment Power BI
   sait-il laquelle utiliser ?
5. Pourquoi relier les ventes par `customer_sk` plutôt que par `customer_id` ?
6. Comment prouves-tu que les chiffres du dashboard sont justes ?
