# Avant J8 — Une installation qui marche du premier coup : guide pas à pas

2 commits, rejoués sur une copie de ton dépôt (`main` = `cdcfc98`) :
hooks verts, 2 tests unitaires de plus.

**Pourquoi ce commit ?** Tu viens de faire ce que fera un recruteur curieux :
cloner le dépôt sur une machine neuve. Le README disait « quelques
minutes », c'était 11. Il fallait coller un script Python pour générer les
secrets. Et deux pièges WSL t'ont bloqué un moment. Un README qui
documente ses vraies frictions montre que le projet a **vraiment** été
installé ailleurs que sur la machine de son auteur : c'est un signal fort.

## Étape 0 — Préparer

```bash
cd ~/projects/rail-ticketing-data-platform
git pull && git status                          # propre, sur "docs: fix the architecture diagram..."
unzip -o /mnt/c/Users/<toi>/Downloads/env-reference.zip -d ~ && REF=~/env-reference
```

---

## Commit 1 — `make env`

```bash
mkdir -p scripts
cp $REF/scripts/new_env.py scripts/
cp $REF/tests/unit/test_new_env.py tests/unit/
cp $REF/Makefile .
git diff                                        # Makefile : la cible env, 3 lignes
make test                                       # 87 passed (2 de plus)
```

**Essaie-le sans toucher à ton `.env`** (il contient les mots de passe de
tes bases, il ne doit pas bouger) :

```bash
make env                                        # refuse : ".env already exists", c'est voulu
cp .env /tmp/env.bak && mv .env /tmp/env.mine   # mets le tien de côté
make env && grep -c change_me .env              # 0 : tout est aléatoire
grep -E "PASSWORD|FERNET" .env | head -3        # des valeurs différentes à chaque fois
mv /tmp/env.mine .env                           # remets le tien
```

```bash
git add scripts tests Makefile
git commit -m "feat: add make env to create .env with random secrets"
```

**À lire dans `new_env.py` :**

- **Pourquoi refuser d'écraser ?** Les mots de passe de `.env` sont
  ceux avec lesquels les bases ont été **créées** (la première fois
  seulement, dans le volume Docker). Si on les régénère, `.env` et les
  bases ne sont plus d'accord, et plus rien ne se connecte. Un outil qui
  peut détruire ta config en une commande, c'est un piège.
- **Pourquoi `token_urlsafe` ?** Ces mots de passe finissent dans des URL
  de connexion (`postgresql://user:motdepasse@host/...`). Un `@`, un `/`
  ou un `:` casserait l'URL. `token_urlsafe` ne produit que des lettres,
  des chiffres, `-` et `_`.
- **Pourquoi une fonction à part pour la clé Fernet ?** Ce n'est pas un
  mot de passe mais une clé de chiffrement au format imposé : 32 octets
  en base64. Le test vérifie qu'elle se décode bien en 32 octets.
- **Pourquoi uniquement la bibliothèque standard ?** `make env` est la
  première commande d'une installation, avant `make install`. Le script
  ne peut compter sur aucun paquet installé.

---

## Commit 2 — Le README dit la vérité

```bash
cp $REF/README.md .
git diff README.md                              # Requirements, make env, durées mesurées, Troubleshooting
git add README.md
git commit -m "docs: installation requirements, real start-up times and troubleshooting"
make lint && git push
```

Ce qui change, et pourquoi :

| Avant | Après | Pourquoi |
|---|---|---|
| « Docker » | Docker Desktop **pour Windows** avec l'intégration WSL, pas Docker Desktop pour Linux dans WSL | C'est le piège qui t'a bloqué `apt` |
| rien sur la mémoire | environ 2,4 Go | Ce que tu as mesuré avec `docker stats` en J5 |
| « quelques minutes » | **~11 min** la 1re fois, **~2 min** ensuite | Tes chiffres : 10 min 53 s et 2 min 14 s |
| écrire `.env` à la main | `make env` | Commit 1 |
| rien | une section *Troubleshooting* | Tes frictions, avec leur solution |

> **Pourquoi 2 minutes même « à chaud » ?** Les images sont déjà là, mais
> `docker compose up --wait` attend que chaque service soit déclaré *sain*
> par son healthcheck, et les healthchecks ne passent qu'à leur intervalle.
> Airflow vérifie aussi que sa base est migrée avant de démarrer ses
> services, et le scheduler, l'API et le dag-processor démarrent l'un après
> l'autre. Ce n'est pas un problème : c'est le prix d'un démarrage qui ne
> dit « prêt » que lorsqu'il l'est vraiment.

Vérifie sur GitHub que le tableau *Troubleshooting* s'affiche bien (la
commande `netstat` contient un `\|` échappé pour ne pas casser le tableau).

Pas de tag pour ce commit : il rejoindra `v0.9.0` avec J8.

## Ce que tu as bien fait

Tu as modifié les mots de passe des bases à la main **puis** lancé le
script pour les secrets Airflow : c'est exactement juste. Les deux se
valent, du moment qu'aucune valeur `change_me` ne reste et qu'on ne
change plus les mots de passe une fois les bases créées. `make env` fait
simplement les deux en une commande.

## Question d'entretien

« Tu as testé ton installation sur une autre machine ? Qu'est-ce qui a
coincé ? » Tu as maintenant une vraie réponse, avec des chiffres.
